<template>
  <div>
      <p>{{con}}</p>
  </div>
</template>

<script>
export default {
    data(){
        return{
            con:null
        }
    },
    created(){
         
    }

}
</script>

<style>

</style>
